function proceso(){
    
let greiber = "Greiber";
console.log(greiber);
let ns = "resta";
console.log(ns);
let casa = 50;
let departamento = 5;
let resta2 = casa-departamento;
console.log(resta2);
    let nop = "multiplicacion";
console.log(nop);
let ori = 15;
let no = 3;
let multiplicacion2 = ori*no;
console.log(multiplicacion2);
let x = 32;
let x3 = 13;
let nsxd = "suma";
console.log(nsxd);
let suma2 = x+x3;
console.log(suma2);
} 
